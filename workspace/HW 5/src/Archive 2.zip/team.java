/*
 * Author: Israel Beh
 * Description: this contains the attributes of the team. A variety of methods are defined here also.
 */
public class team {
		
	String teamName;
	int	wins;
	int losses;
	int totalRunsFor;
	int	totalRunsAgainst;
	double winLossPct;
	
	String getTeam ()
	{
		return this.teamName;
	}
	public void setTeam(String sTeamName)
	{
		this.teamName = sTeamName;	
	}
	void setWinLosses(int iWins, int iLosses)
	{
		this.wins = iWins;
		this.losses = iLosses;
		this.winLossPct = (double) iWins / ((double) iLosses + (double) iWins);
	}
	int getWins()
	{
		return this.wins;
	}
	
	int getLosses()
	{
		return this.losses;
	}
	
	void addRunsFor (int runsFor)
	{
		this.totalRunsFor = this.totalRunsFor + runsFor;
	}
	
	void addRunsAgainst (int runsAgainst)
	{
		this.totalRunsAgainst = this.totalRunsAgainst + runsAgainst;
	}
	
	void getAllRuns ()
	{
		System.out.println("Runs for " + this.totalRunsFor + " and Runs Against " + 
							this.totalRunsAgainst);
	}
}
