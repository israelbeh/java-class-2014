/*
 Author: Israel Beh
 Description: the attributes of the object that holds the names of the boy and the girl that are
 stored in the same array.
 */
public class Names {
	String boy;
	String girl;
	
	
}
