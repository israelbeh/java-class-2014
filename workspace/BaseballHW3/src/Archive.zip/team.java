/*
 * Author: Israel Beh
 * Description: Homework 4
 */
public class team {
	
	String teamName;//Holds the name of the team
	int wins;//holds the value for wins
	int losses;//holds the value for losses
	int totalRunsFor;//holds the value for total runs
	int totalRunsAgainst;// holds the value for total runs score against team
	Double winLossPct;//holds the value of total wins/ each game played.
	boolean bIsHomeTeam = true;//determines who is the home team
	
	
	/*team ()// this is the constructor which is the method. same name as the class. It creates an object
	{
		
	}
	team (String sTeamName, int iWins, int iLosses, int iTotalRunsFor, int iTotalRunsAgainst, Double dWinLossPct)//this assigns parameters to attributes
	{
		this.teamName = sTeamName;// "this" refers to the attribute
		this.wins = iWins;
		this.losses = iLosses;
		this.totalRunsFor = iTotalRunsFor;
		this.totalRunsAgainst = iTotalRunsAgainst;
		this.winLossPct = dWinLossPct;
	}
	
	

	{
		
	}
	*/
}
