
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author israelbeh
 */
public class Student {
    
      double CalcGPA(String sLetterGrade, double iWeight)
    {
//Method here dtotal =dcredits * 4.0, return dTotal put in student class
 
        String sGrd = sLetterGrade;
        double dWeight =0;
        
        double dTotal;

        if (sGrd.equalsIgnoreCase("A"))
            dWeight = 4.0 * iWeight;
            
        else if (sGrd.equalsIgnoreCase("A-"))
            dWeight = 3.7* iWeight;
        else if (sGrd.equalsIgnoreCase("B+"))
            dWeight = 3.4*iWeight;
        else if (sGrd.equalsIgnoreCase("B"))
            dWeight = 3.0*iWeight;
        else if (sGrd.equalsIgnoreCase("B-"))
            dWeight = 2.7*iWeight;
        else if (sGrd.equalsIgnoreCase("C+"))
            dWeight = 2.4*iWeight;
        else if (sGrd.equalsIgnoreCase("C"))
            dWeight = 2.0*iWeight;
        else if (sGrd.equalsIgnoreCase("C-"))
            dWeight = 1.7*iWeight;
        else if (sGrd.equalsIgnoreCase("D+"))
            dWeight = 1.4*iWeight;
        else if (sGrd.equalsIgnoreCase("D"))
            dWeight = 1.0*iWeight;
       else if (sGrd.equalsIgnoreCase("D-"))
            dWeight = 0.7*iWeight;
       else if (sGrd.equalsIgnoreCase("E"))
            dWeight = 0.0*iWeight;
       
        
        return dWeight;
        
        
   
    }
    
}
